namespace WikipediaNET.Enums
{
    public enum Format
    {
        Default,
        XML,
        JSON
    }
}