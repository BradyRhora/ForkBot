# OxfordDictionariesAPI
Unofficial Oxford Dictionaries API in .NET.
## Requirement
- .NET Standard 1.1

## Available API
-  `/entries/{source_lang}/{word_id}`  

## Nuget
`Install-Package OxfordDictionariesAPI`
